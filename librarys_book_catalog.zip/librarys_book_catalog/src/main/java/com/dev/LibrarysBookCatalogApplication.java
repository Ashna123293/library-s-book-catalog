package com.dev;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LibrarysBookCatalogApplication {

	public static void main(String[] args) {
		SpringApplication.run(LibrarysBookCatalogApplication.class, args);
	}

}
